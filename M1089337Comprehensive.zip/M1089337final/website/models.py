products_list = {
        1: {
            "name": "Shoe",
            "img": "footwear.jpg",
            "title": "easy and comfort with your feet"
        },
        2: {
            "name": "Bags",
            "img": "bag.jpg",
            "title": "we believe travel should be fun. We take pride in making stylish, high quality, and yeah, fun backpacks that you can rely on."
        },
        3: {
            "name": "Mobile",
            "img": "mobile.jpg",
            "title": "The OPPO F19 is a smartphone designed and created to match your dynamic and stylish lifestyle. This smartphone features a 5000 mAh Battery for uninterrupted use"
        },
        4: {
            "name": "Headset",
            "img": "headset.jpg",
            "title": "feel the new experience"
        },
        5: {
            "name": "Jewellery",
            "img": "jewellery.jpg",
            "title": "beauty attracts the attention of people among other and it distiguish you from others "
        },
        6: {
            "name": "Laptop",
            "img": "laptop.jpg",
            "title": "laptop with high performance"
        },
        7: {
            "name": "T shirt",
            "img": "tshirt.jpg",
            "title": "latest style"
        }
        
    }
  
empty_cart={}
for key,value in products_list.items():
    empty_cart[key]={
        'name':value['name']
        ,
        'quantity':0
    }
